D=[inf 7 8 2 inf inf 3 inf;
    7 inf 1 inf 2 inf inf 3;
    8 1 inf 4 2 7 inf inf;
    2 inf 4 inf inf 4 6 inf;
    inf 2 2 inf inf 5 inf 1;
    inf inf 7 4 5 inf 4 3;
    3 inf inf 6 inf 4 inf 6;
    inf 3 inf inf 1 3 6 inf];
n=8;